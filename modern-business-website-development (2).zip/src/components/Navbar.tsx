import { useEffect, useState } from "react";
import { BUSINESS } from "../utils/contact";
import { IconMenu, IconClose, IconWhatsApp } from "./Icons";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#services", label: "Services" },
  { href: "#process", label: "Process" },
  { href: "#portfolio", label: "Portfolio" },
  { href: "#contact", label: "Contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-ink/85 backdrop-blur-xl border-b border-white/5" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8 lg:h-20">
        <a href="#home" className="group flex items-center gap-2.5">
          <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-ink font-black">
            B
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-gold-light animate-blink" />
          </span>
          <div className="leading-tight">
            <div className="text-sm font-bold tracking-tight text-white sm:text-base">
              Bjay<span className="text-gold-light">.Elite</span>
            </div>
            <div className="hidden text-[10px] uppercase tracking-[0.18em] text-white/40 sm:block">
              Business Solutions
            </div>
          </div>
        </a>

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="group relative text-sm font-medium text-white/70 transition-colors hover:text-white"
            >
              {l.label}
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-gradient-to-r from-gold-light to-gold-dark transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={`https://wa.me/${BUSINESS.whatsappRaw}`}
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-5 py-2.5 text-sm font-semibold text-ink shadow-lg shadow-gold/20 transition-all hover:shadow-gold/40 hover:scale-[1.03]"
          >
            <IconWhatsApp className="h-4 w-4" />
            WhatsApp
          </a>
        </div>

        <button
          aria-label="Toggle menu"
          className="rounded-lg border border-white/10 p-2 text-white lg:hidden"
          onClick={() => setOpen((s) => !s)}
        >
          {open ? <IconClose className="h-5 w-5" /> : <IconMenu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-500 ${
          open ? "max-h-[480px] border-t border-white/5 bg-ink/95 backdrop-blur-xl" : "max-h-0"
        }`}
      >
        <nav className="flex flex-col gap-1 px-5 py-4">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-4 py-3 text-sm font-medium text-white/80 transition-colors hover:bg-white/5 hover:text-white"
            >
              {l.label}
            </a>
          ))}
          <a
            href={`https://wa.me/${BUSINESS.whatsappRaw}`}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-5 py-3 text-sm font-semibold text-ink"
          >
            <IconWhatsApp className="h-4 w-4" />
            Chat on WhatsApp
          </a>
        </nav>
      </div>
    </header>
  );
}
