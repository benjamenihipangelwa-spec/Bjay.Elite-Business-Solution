import { BUSINESS, whatsappMessages, mailLink } from "../utils/contact";
import { IconWhatsApp, IconMail, IconArrowRight, IconSparkles } from "./Icons";

export default function WhatsAppConsult() {
  return (
    <section id="whatsapp" className="relative overflow-hidden bg-ink py-20 sm:py-28">
      <div className="pointer-events-none absolute -left-32 top-20 h-72 w-72 rounded-full bg-gold/8 blur-3xl" />
      <div className="pointer-events-none absolute -right-40 bottom-20 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />

      <div className="mx-auto max-w-5xl px-5 sm:px-8">
        <div className="reveal relative overflow-hidden rounded-3xl border border-gold/25 bg-gradient-to-br from-[#101010] via-[#0a0a0a] to-[#16110a] p-8 sm:p-14">
          <div className="pointer-events-none absolute -right-10 -top-10 h-44 w-44 rounded-full bg-gold/15 blur-3xl" />

          <div className="relative flex flex-col items-center text-center">
            <div className="relative">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-[#25D366] to-[#128C7E] text-white shadow-xl shadow-emerald-900/30">
                <IconWhatsApp className="h-8 w-8" />
              </div>
              <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-ink animate-pulse" />
            </div>

            <h2 className="mt-6 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl lg:text-5xl">
              Let's build your <span className="text-gold-gradient">digital solution</span>
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/70 sm:text-lg">
              Have an idea for a website, Excel system, business application or digital
              solution? Contact Bjay.Elite and let's discuss your requirements — quickly
              and directly, the way you prefer.
            </p>

            <div className="mt-9 grid w-full max-w-3xl gap-4 sm:grid-cols-3">
              {[
                ["Quick Response", "Get a reply within hours."],
                ["Tailored Advice", "We recommend the right solution."],
                ["No Obligation", "Free initial consultation."],
              ].map(([t, d]) => (
                <div key={t} className="rounded-2xl border border-white/5 bg-white/[0.03] p-4 text-left">
                  <div className="flex h-7 w-7 items-center justify-center rounded-md bg-gold/10 text-gold-light">
                    <IconSparkles className="h-3.5 w-3.5" />
                  </div>
                  <div className="mt-2.5 text-sm font-semibold text-white">{t}</div>
                  <div className="mt-1 text-xs leading-relaxed text-white/55">{d}</div>
                </div>
              ))}
            </div>

            <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
              <a
                href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(whatsappMessages.general)}`}
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-2 rounded-full bg-[#25D366] px-7 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-900/30 transition-all hover:scale-[1.02]"
              >
                <IconWhatsApp className="h-5 w-5" />
                Chat on WhatsApp
                <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href={mailLink("Project Enquiry — Bjay.Elite", "Hello Bjay.Elite,\n\nI'd like to discuss a project.")}
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-7 py-3.5 text-sm font-semibold text-white transition-all hover:border-gold-light/40 hover:bg-white/[0.08]"
              >
                <IconMail className="h-4 w-4" />
                Send an Email
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
