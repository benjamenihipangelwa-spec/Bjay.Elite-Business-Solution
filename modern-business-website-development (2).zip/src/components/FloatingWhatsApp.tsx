import { BUSINESS } from "../utils/contact";
import { IconWhatsApp } from "./Icons";
import { useEffect, useState } from "react";

export default function FloatingWhatsApp() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setShow(true), 800);
    return () => clearTimeout(t);
  }, []);

  return (
    <a
      href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(
        "Hello Bjay.Elite, I would like to enquire about your services."
      )}`}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat with Bjay.Elite on WhatsApp"
      className={`group fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-2xl shadow-emerald-900/30 transition-all duration-500 sm:bottom-7 sm:right-7 sm:h-16 sm:w-16 ${
        show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
      } animate-pulse-gold`}
    >
      <IconWhatsApp className="h-7 w-7 sm:h-8 sm:w-8 transition-transform group-hover:scale-110" />
      <span className="absolute right-full mr-3 hidden whitespace-nowrap rounded-full bg-white px-3 py-1.5 text-xs font-medium text-ink shadow-lg md:block opacity-0 -translate-x-2 transition-all group-hover:opacity-100 group-hover:translate-x-0">
        Chat with us
      </span>
    </a>
  );
}
