import { BUSINESS } from "../utils/contact";
import { downloadHostingGuide } from "../utils/hostingGuidePdf";
import {
  IconWhatsApp,
  IconMail,
  IconPhone,
  IconMapPin,
  IconFacebook,
  IconInstagram,
  IconTikTok,
  IconLinkedIn,
  IconServer,
} from "./Icons";

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/5 bg-[#080808]">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[600px] -translate-x-1/2 rounded-full bg-gold/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <a href="#home" className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-ink font-black">
                B
              </span>
              <div className="leading-tight">
                <div className="text-lg font-bold tracking-tight text-white">
                  Bjay<span className="text-gold-light">.Elite</span>
                </div>
                <div className="text-[10px] uppercase tracking-[0.18em] text-white/40">
                  Business Solutions
                </div>
              </div>
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/60">
              “Smart Digital Solutions for Businesses.” From websites to Excel systems and
              automation, we help businesses operate more professionally and grow with
              confidence.
            </p>

            <div className="mt-6 flex items-center gap-3">
              <SocialLink href={BUSINESS.socials.facebook} label="Facebook"><IconFacebook className="h-4 w-4" /></SocialLink>
              <SocialLink href={BUSINESS.socials.instagram} label="Instagram"><IconInstagram className="h-4 w-4" /></SocialLink>
              <SocialLink href={BUSINESS.socials.tiktok} label="TikTok"><IconTikTok className="h-4 w-4" /></SocialLink>
              <SocialLink href={BUSINESS.socials.linkedin} label="LinkedIn"><IconLinkedIn className="h-4 w-4" /></SocialLink>
            </div>
          </div>

          <div className="lg:col-span-2">
            <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold-light">
              Quick Links
            </h4>
            <ul className="mt-5 space-y-2.5 text-sm text-white/65">
              {[
                ["Home", "#home"],
                ["About", "#about"],
                ["Services", "#services"],
                ["Portfolio", "#portfolio"],
                ["Consultation", "#booking"],
                ["Contact", "#contact"],
              ].map(([label, href]) => (
                <li key={label}>
                  <a href={href} className="hover:text-gold-light transition-colors">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-3">
            <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold-light">
              Services
            </h4>
            <ul className="mt-5 space-y-2.5 text-sm text-white/65">
              {[
                "Web Development",
                "Excel Systems",
                "Business Systems",
                "Automation",
                "AI Solutions",
                "Consulting",
                "Branding",
                "Digital Marketing",
              ].map((label) => (
                <li key={label}>
                  <a href="#services" className="hover:text-gold-light transition-colors">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-3">
            <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold-light">
              Contact
            </h4>
            <ul className="mt-5 space-y-3 text-sm text-white/70">
              <li className="flex items-start gap-3">
                <IconPhone className="mt-0.5 h-4 w-4 shrink-0 text-gold-light" />
                <a href={`tel:${BUSINESS.whatsappDisplay}`} className="hover:text-gold-light transition-colors">
                  {BUSINESS.whatsappDisplay}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <IconMail className="mt-0.5 h-4 w-4 shrink-0 text-gold-light" />
                <a href={`mailto:${BUSINESS.email}`} className="hover:text-gold-light transition-colors break-all">
                  {BUSINESS.email}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <IconMapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-light" />
                <span>{BUSINESS.location}</span>
              </li>
              <li className="flex items-start gap-3">
                <IconWhatsApp className="mt-0.5 h-4 w-4 shrink-0 text-gold-light" />
                <a
                  href={`https://wa.me/${BUSINESS.whatsappRaw}`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-gold-light transition-colors"
                >
                  Chat on WhatsApp
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-3 border-t border-white/5 pt-8">
          <button
            onClick={() => downloadHostingGuide()}
            className="group inline-flex items-center gap-2 rounded-full border border-gold/25 bg-gold/5 px-5 py-2.5 text-xs font-semibold text-gold-light transition-all hover:border-gold-light/50 hover:bg-gold-light/10"
          >
            <IconServer className="h-3.5 w-3.5" />
            Download Free Hosting Guide (PDF)
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5 transition-transform group-hover:translate-y-0.5">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </button>
        </div>

        <div className="mt-6 flex flex-col items-center justify-between gap-4 text-xs text-white/45 md:flex-row">
          <p>© 2026 Bjay.Elite Business Solutions. All Rights Reserved.</p>
          <p>
            Crafted with <span className="text-gold-light">♥</span> for modern businesses in Namibia & beyond.
          </p>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({ href, label, children }: { href: string; label: string; children: React.ReactNode }) {
  const isPlaceholder = href === "#";
  if (isPlaceholder) {
    return (
      <button
        disabled
        aria-label={label}
        title={`${label} — profile link not provided yet`}
        className="flex h-9 w-9 cursor-not-allowed items-center justify-center rounded-full border border-white/10 bg-white/[0.02] text-white/30 transition-colors"
      >
        {children}
      </button>
    );
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      aria-label={label}
      className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.02] text-white/60 transition-all hover:border-gold-light hover:bg-gold-light hover:text-ink"
    >
      {children}
    </a>
  );
}
