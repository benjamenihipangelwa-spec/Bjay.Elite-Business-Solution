import { useState } from "react";
import { IconChevronDown, IconWhatsApp, IconMail } from "./Icons";
import { BUSINESS, mailLink, whatsappMessages } from "../utils/contact";

const faqs = [
  {
    q: "Do you build websites?",
    a: "Yes. We create professional websites for businesses, individuals, startups and organizations — including static sites, company sites, portfolios, landing pages, restaurants, booking sites, e-commerce and more.",
  },
  {
    q: "Do you create Excel systems?",
    a: "Yes. We create customized Excel spreadsheets with formulas, automation, dashboards, reports and professional formatting — for accounting, stock, payroll, invoicing and other business needs.",
  },
  {
    q: "Can you build a custom business system?",
    a: "Yes. We can develop customized web-based systems according to the client's requirements — including management dashboards, booking systems, inventory systems and customer/employee registers.",
  },
  {
    q: "Can you help with hosting?",
    a: "Yes. We can assist with domain selection, hosting, deployment, SSL setup, business email setup, website migration and ongoing maintenance.",
  },
  {
    q: "Do you provide business consulting?",
    a: "Yes. We provide digital and technology-focused business consultation covering digital transformation, online presence, website planning, system planning and process improvement.",
  },
  {
    q: "Can I request a customized service?",
    a: "Yes. Clients can contact Bjay.Elite with a description of what they need and we will advise on the best practical approach and provide a quotation.",
  },
  {
    q: "How do I get a quotation?",
    a: "Contact us through WhatsApp or email and provide your project requirements. We will respond with a customized quotation based on your specific needs.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="relative overflow-hidden bg-[#0b0b0b] py-20 sm:py-28">
      <div className="pointer-events-none absolute -right-32 top-20 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />
      <div className="mx-auto max-w-4xl px-5 sm:px-8">
        <div className="text-center reveal">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            FAQ
          </div>
          <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
            Frequently asked <span className="text-gold-gradient">questions</span>
          </h2>
          <p className="mt-5 text-base leading-relaxed text-white/65">
            Answers to common questions about our digital solutions, process and pricing.
          </p>
        </div>

        <div className="mt-12 space-y-3 reveal">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div
                key={f.q}
                className={`overflow-hidden rounded-2xl border bg-white/[0.02] transition-all ${
                  isOpen ? "border-gold/30 bg-white/[0.04]" : "border-white/5"
                }`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left sm:px-6 sm:py-5"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm font-semibold text-white sm:text-base">{f.q}</span>
                  <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all ${
                    isOpen ? "rotate-180 border-gold-light bg-gold-light text-ink" : "border-white/10 text-white/60"
                  }`}>
                    <IconChevronDown className="h-4 w-4" />
                  </span>
                </button>
                <div className={`grid transition-all duration-500 ${
                  isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                }`}>
                  <div className="overflow-hidden">
                    <div className="px-5 pb-5 text-sm leading-relaxed text-white/65 sm:px-6">
                      {f.a}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 reveal rounded-3xl border border-gold/20 bg-gradient-to-br from-[#15110a] to-[#0a0a0a] p-7 sm:p-9">
          <h3 className="text-xl font-bold text-white sm:text-2xl">Still have a question?</h3>
          <p className="mt-2 text-sm text-white/65 sm:text-base">
            Reach out — we usually respond within a few hours.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(whatsappMessages.general)}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-5 py-2.5 text-sm font-semibold text-white transition-all hover:scale-[1.02]"
            >
              <IconWhatsApp className="h-4 w-4" />
              Chat on WhatsApp
            </a>
            <a
              href={mailLink("Question — Bjay.Elite", "Hello Bjay.Elite,\n\nI have a question about your services.")}
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-sm font-semibold text-white transition-all hover:border-gold-light/40"
            >
              <IconMail className="h-4 w-4" />
              Send an Email
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
