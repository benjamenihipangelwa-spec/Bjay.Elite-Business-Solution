import { BUSINESS, whatsappMessages, mailLink } from "../utils/contact";
import { IconWhatsApp, IconMail, IconArrowRight, IconSparkles, IconShield } from "./Icons";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative isolate overflow-hidden bg-ink pt-28 pb-20 sm:pt-36 lg:pt-40 lg:pb-28"
    >
      {/* Background layers */}
      <div className="absolute inset-0 hero-grid opacity-60" />
      <div className="pointer-events-none absolute -top-32 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-gold/10 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-96 w-96 rounded-full bg-gold/5 blur-3xl" />

      {/* Floating decorative rings */}
      <div className="pointer-events-none absolute right-10 top-32 hidden h-56 w-56 rounded-full border border-gold/10 animate-spin-slow lg:block" />
      <div className="pointer-events-none absolute right-24 top-44 hidden h-32 w-32 rounded-full border border-gold/20 lg:block" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <div className="inline-flex animate-fade-up items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            <IconSparkles className="h-3.5 w-3.5" />
            <span>Smart Digital Solutions for Businesses</span>
          </div>

          <h1 className="mt-6 max-w-3xl text-[2.6rem] font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl lg:text-7xl">
            Build. <span className="text-gold-gradient">Automate.</span> Grow.
          </h1>

          <p className="mt-6 max-w-2xl text-base leading-relaxed text-white/65 sm:text-lg">
            Professional websites, business systems, Excel solutions and digital services
            designed to help your business work smarter. From <strong className="text-white/90">Namibia to the world</strong>,
            Bjay.Elite turns ideas into practical digital solutions.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(whatsappMessages.booking)}`}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-7 py-3.5 text-sm font-bold text-ink shadow-xl shadow-gold/20 transition-all hover:shadow-gold/40 hover:scale-[1.02]"
            >
              <IconWhatsApp className="h-5 w-5" />
              Book a Consultation
              <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#services"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.03] px-7 py-3.5 text-sm font-semibold text-white backdrop-blur transition-all hover:border-gold-light/40 hover:bg-white/[0.06]"
            >
              View Our Services
            </a>
            <a
              href={mailLink("Enquiry — Bjay.Elite", "Hello Bjay.Elite,\n\nI'd like to enquire about your services.")}
              className="inline-flex items-center gap-2 px-2 py-3 text-sm font-medium text-white/65 underline-offset-4 hover:text-gold-light hover:underline"
            >
              <IconMail className="h-4 w-4" />
              Or send us an email
            </a>
          </div>

          <div className="mt-12 grid max-w-2xl grid-cols-3 gap-4 sm:gap-8">
            {[
              ["12+", "Service Areas"],
              ["Custom", "Built Solutions"],
              ["Namibia", "& Beyond"],
            ].map(([v, l]) => (
              <div key={l} className="border-l border-white/10 pl-3 sm:pl-4">
                <div className="text-xl font-bold text-gold-light sm:text-2xl">{v}</div>
                <div className="mt-1 text-[11px] uppercase tracking-wider text-white/50 sm:text-xs">{l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Hero visual */}
        <div className="relative lg:col-span-5">
          <div className="relative animate-fade-up [animation-delay:200ms]">
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-gold/20 via-transparent to-gold/5 blur-2xl" />
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-2 shadow-2xl shadow-gold/5">
              <img
                src="/images/hero.jpg"
                alt="Bjay.Elite modern digital business workspace"
                className="h-[360px] w-full rounded-2xl object-cover sm:h-[460px]"
                loading="eager"
              />
              {/* Floating mini card */}
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between rounded-2xl border border-white/10 bg-black/60 p-4 backdrop-blur-xl animate-float">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-ink">
                    <IconShield className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs text-white/55">Trusted solutions</div>
                    <div className="text-sm font-semibold text-white">Built for your business</div>
                  </div>
                </div>
                <div className="hidden text-xs text-gold-light sm:block">↗ Live</div>
              </div>
            </div>

            {/* Floating tag */}
            <div className="absolute -top-3 -left-3 hidden rounded-xl border border-gold/20 bg-ink/90 px-3 py-2 text-xs font-medium text-gold-light shadow-lg backdrop-blur sm:block">
              ✦ Digital · Web · Excel · AI
            </div>
          </div>
        </div>
      </div>

      {/* Marquee strip */}
      <div className="relative mt-16 overflow-hidden border-y border-white/5 bg-white/[0.02] py-3 sm:mt-24">
        <div className="marquee-track flex w-max items-center gap-12 whitespace-nowrap text-sm font-medium uppercase tracking-[0.25em] text-white/40">
          {[...Array(2)].flatMap((_, i) =>
            [
              "Website Development",
              "Excel Systems",
              "Business Documents",
              "Digital Automation",
              "AI Solutions",
              "Business Consulting",
              "Branding & Design",
              "Website Hosting",
              "Training",
            ].map((t, j) => (
              <span key={`${i}-${j}`} className="flex items-center gap-12">
                {t}
                <span className="text-gold/60">◆</span>
              </span>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
