import { IconCheck, IconArrowRight } from "./Icons";

const highlights = [
  { t: "Affordable Solutions", d: "Practical pricing tailored for individuals, startups and growing businesses." },
  { t: "Professional Service", d: "Clean, modern and business-focused results built to a high standard." },
  { t: "Custom-Built Systems", d: "Every solution is designed around the specific way your business operates." },
  { t: "Business-Focused Technology", d: "We choose tools and platforms that deliver real-world value." },
  { t: "Support & Consultation", d: "We help you understand, use and grow with the solutions we build." },
];

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden bg-[#0b0b0b] py-20 sm:py-28">
      <div className="pointer-events-none absolute -left-32 top-20 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="relative reveal">
              <div className="absolute -inset-3 rounded-3xl bg-gradient-to-br from-gold/30 to-transparent opacity-30 blur-2xl" />
              <img
                src="/images/about.jpg"
                alt="Bjay.Elite workspace"
                className="relative h-[420px] w-full rounded-3xl object-cover sm:h-[520px]"
                loading="lazy"
              />
              <div className="absolute -bottom-5 -right-5 hidden rounded-2xl border border-gold/20 bg-ink/90 px-5 py-4 shadow-2xl backdrop-blur sm:block">
                <div className="text-3xl font-bold text-gold-gradient">10+</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-white/60">Solution areas</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 reveal">
            <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
              About Bjay.Elite
            </div>
            <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl lg:text-5xl">
              Turning ideas into <span className="text-gold-gradient">practical digital solutions</span>.
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/70 sm:text-lg">
              Bjay.Elite Business Solutions helps individuals and businesses turn ideas into
              practical digital solutions. From professional websites and customized Excel
              systems to business documents, automation and digital consulting, we provide
              solutions tailored to each client's needs.
            </p>

            <ul className="mt-8 grid gap-4 sm:grid-cols-2">
              {highlights.map((h) => (
                <li
                  key={h.t}
                  className="group flex gap-3 rounded-2xl border border-white/5 bg-white/[0.02] p-4 transition-all hover:border-gold/30 hover:bg-white/[0.04]"
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-ink">
                    <IconCheck className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">{h.t}</div>
                    <div className="mt-1 text-xs leading-relaxed text-white/60">{h.d}</div>
                  </div>
                </li>
              ))}
            </ul>

            <a
              href="#contact"
              className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-gold-light hover:gap-3 transition-all"
            >
              Let's discuss your project
              <IconArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
