import { useEffect, useRef, useState } from "react";
import { BUSINESS } from "../utils/contact";
import { findAnswer, FALLBACK_ANSWER, SUGGESTED_QUESTIONS } from "../utils/knowledge";

type Message = {
  id: number;
  role: "user" | "bot";
  text: string;
  ts: number;
};

// Initial greeting based strictly on what the website says
const INITIAL_MESSAGES: Message[] = [
  {
    id: 1,
    role: "bot",
    text:
      "Hi 👋 I'm BjayBot, the website assistant for Bjay.Elite Business Solutions. I can answer questions based only on what's published on this site. Try one of the suggestions below or type your question.",
    ts: Date.now(),
  },
];

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  // Auto-scroll
  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages, typing, open]);

  // Open the chat after a short delay for visibility
  useEffect(() => {
    const t = setTimeout(() => setOpen(false), 0); // start closed; user opens it
    return () => clearTimeout(t);
  }, []);

  const send = (raw: string) => {
    const text = raw.trim();
    if (!text) return;
    const userMsg: Message = {
      id: Date.now(),
      role: "user",
      text,
      ts: Date.now(),
    };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setTyping(true);

    // Simulate typing so the response feels natural
    const delay = 450 + Math.min(900, text.length * 12);
    setTimeout(() => {
      const answer = findAnswer(text) ?? FALLBACK_ANSWER;
      setMessages((m) => [
        ...m,
        { id: Date.now() + 1, role: "bot", text: answer, ts: Date.now() },
      ]);
      setTyping(false);
    }, delay);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    send(input);
  };

  const handleClear = () => {
    setMessages(INITIAL_MESSAGES);
  };

  return (
    <>
      {/* Floating launcher — sits ABOVE the WhatsApp button */}
      <button
        aria-label={open ? "Close chat assistant" : "Open chat assistant"}
        onClick={() => setOpen((s) => !s)}
        className={`fixed bottom-5 left-5 z-40 flex h-14 w-14 items-center justify-center rounded-full text-white shadow-2xl transition-all duration-300 sm:bottom-7 sm:left-7 sm:h-16 sm:w-16 ${
          open
            ? "bg-ink border border-gold/40 rotate-90"
            : "bg-gradient-to-br from-gold-light to-gold-dark text-ink shadow-gold/30 animate-pulse-gold"
        }`}
      >
        {open ? (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-7 w-7">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            <circle cx="8" cy="10" r="1" fill="currentColor" />
            <circle cx="12" cy="10" r="1" fill="currentColor" />
            <circle cx="16" cy="10" r="1" fill="currentColor" />
          </svg>
        )}
        {!open && (
          <span className="absolute right-full mr-3 hidden whitespace-nowrap rounded-full bg-white px-3 py-1.5 text-xs font-medium text-ink shadow-lg md:block">
            Chat with BjayBot
          </span>
        )}
      </button>

      {/* Chat panel */}
      <div
        role="dialog"
        aria-label="BjayBot chat assistant"
        aria-hidden={!open}
        className={`fixed bottom-24 left-5 right-5 z-40 mx-auto flex max-h-[min(80vh,640px)] w-auto max-w-md flex-col overflow-hidden rounded-2xl border border-gold/25 bg-[#0a0a0a]/95 shadow-2xl shadow-black/60 backdrop-blur-xl transition-all duration-300 sm:left-auto sm:right-7 sm:bottom-28 sm:w-[380px] ${
          open
            ? "pointer-events-auto translate-y-0 opacity-100"
            : "pointer-events-none translate-y-4 opacity-0"
        }`}
      >
        {/* Header */}
        <div className="relative flex items-center gap-3 border-b border-white/5 bg-gradient-to-br from-[#15110a] to-[#0a0a0a] px-4 py-3.5">
          <div className="relative">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-sm font-black text-ink">
              B
            </div>
            <span className="absolute -right-0.5 -bottom-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-[#0a0a0a]" />
          </div>
          <div className="flex-1 leading-tight">
            <div className="text-sm font-bold text-white">BjayBot</div>
            <div className="text-[11px] text-white/55">Answers from this site only</div>
          </div>
          <button
            onClick={handleClear}
            title="Restart chat"
            className="rounded-lg p-1.5 text-white/50 transition-colors hover:bg-white/5 hover:text-white"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
              <polyline points="1 4 1 10 7 10" />
              <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
            </svg>
          </button>
        </div>

        {/* Messages */}
        <div
          ref={listRef}
          className="flex-1 space-y-3 overflow-y-auto px-4 py-4"
          style={{ scrollBehavior: "smooth" }}
        >
          {messages.map((m) => (
            <Bubble key={m.id} role={m.role} text={m.text} />
          ))}

          {typing && <TypingBubble />}

          {/* Quick replies — only show after the greeting */}
          {messages.length === 1 && !typing && (
            <div className="pt-2">
              <div className="mb-2 text-[11px] uppercase tracking-wider text-white/40">
                Suggested questions
              </div>
              <div className="flex flex-wrap gap-2">
                {SUGGESTED_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    onClick={() => send(q)}
                    className="rounded-full border border-gold/20 bg-gold/5 px-3 py-1.5 text-[12px] font-medium text-gold-light transition-all hover:border-gold-light/40 hover:bg-gold-light/10"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <form
          onSubmit={handleSubmit}
          className="flex items-center gap-2 border-t border-white/5 bg-black/40 px-3 py-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about our services…"
            aria-label="Type your question"
            className="form-input flex-1 !py-2.5 text-sm"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            aria-label="Send message"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold-dark text-ink transition-all hover:scale-105 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
              <line x1="22" y1="2" x2="11" y2="13" />
              <polygon points="22 2 15 22 11 13 2 9 22 2" />
            </svg>
          </button>
        </form>

        {/* Footer tiny note */}
        <div className="flex items-center justify-between border-t border-white/5 px-3 py-1.5 text-[10px] text-white/35">
          <span>Powered by site knowledge only</span>
          <a
            href={`https://wa.me/${BUSINESS.whatsappRaw}`}
            target="_blank"
            rel="noreferrer"
            className="hover:text-gold-light"
          >
            Need a human? WhatsApp →
          </a>
        </div>
      </div>
    </>
  );
}

function Bubble({ role, text }: { role: "user" | "bot"; text: string }) {
  const isBot = role === "bot";
  return (
    <div className={`flex gap-2 ${isBot ? "justify-start" : "justify-end"}`}>
      {isBot && (
        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold-dark text-[10px] font-black text-ink">
          B
        </div>
      )}
      <div
        className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
          isBot
            ? "rounded-bl-sm border border-white/5 bg-white/[0.04] text-white/85"
            : "rounded-br-sm bg-gradient-to-br from-gold-light to-gold-dark text-ink font-medium"
        }`}
      >
        {text}
      </div>
    </div>
  );
}

function TypingBubble() {
  return (
    <div className="flex justify-start gap-2">
      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold-dark text-[10px] font-black text-ink">
        B
      </div>
      <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm border border-white/5 bg-white/[0.04] px-4 py-3">
        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-gold-light [animation-delay:-0.3s]" />
        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-gold-light [animation-delay:-0.15s]" />
        <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-gold-light" />
      </div>
    </div>
  );
}
