import { IconCompass, IconRocket, IconHammer, IconShield, IconStar } from "./Icons";

const steps = [
  { n: "01", icon: IconCompass, title: "Discover", text: "Discuss the client's needs and goals." },
  { n: "02", icon: IconRocket, title: "Plan", text: "Recommend the right solution." },
  { n: "03", icon: IconHammer, title: "Build", text: "Develop and customize the solution." },
  { n: "04", icon: IconShield, title: "Test", text: "Check functionality, responsiveness and quality." },
  { n: "05", icon: IconStar, title: "Deliver", text: "Launch the solution and provide guidance/support." },
];

export default function Process() {
  return (
    <section id="process" className="relative overflow-hidden bg-ink py-20 sm:py-28">
      <div className="pointer-events-none absolute -right-32 top-40 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center reveal">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            Our Process
          </div>
          <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
            A clear <span className="text-gold-gradient">5-step</span> journey
          </h2>
          <p className="mt-5 text-base leading-relaxed text-white/65">
            Every project follows a simple, transparent process so you always know what's happening.
          </p>
        </div>

        <div className="relative mt-14">
          {/* Connector line */}
          <div className="pointer-events-none absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-gold/40 via-gold/10 to-transparent lg:block" />

          <div className="space-y-6 lg:space-y-0 lg:grid lg:grid-cols-1">
            {steps.map((s, i) => {
              const Icon = s.icon;
              const isLeft = i % 2 === 0;
              return (
                <div
                  key={s.n}
                  className="reveal relative lg:grid lg:grid-cols-2 lg:items-center lg:gap-12"
                >
                  <div className={`hidden lg:block ${isLeft ? "" : "lg:order-2"}`} />
                  <div className={`hidden lg:block ${isLeft ? "lg:order-2" : ""}`} />

                  <div className={`relative ${isLeft ? "lg:pr-12 lg:text-right" : "lg:pl-12 lg:col-start-2"}`}>
                    {/* Node */}
                    <div className="absolute right-0 top-6 hidden h-4 w-4 -translate-y-1/2 translate-x-1/2 rounded-full bg-gradient-to-br from-gold-light to-gold-dark shadow-lg shadow-gold/30 lg:block" style={{
                      [isLeft ? "right" : "left"]: "-0.5rem",
                    }} />

                    <div className={`group flex gap-5 rounded-2xl border border-white/5 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-6 transition-all hover:border-gold/30 hover:shadow-lg hover:shadow-gold/5 lg:flex-row ${isLeft ? "lg:flex-row-reverse" : ""}`}>
                      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-gold-light/20 to-gold-dark/10 text-gold-light ring-1 ring-gold/20 transition-transform group-hover:scale-105">
                        <Icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <span className="text-gold-gradient font-extrabold tracking-tighter">{s.n}</span>
                          <span className="h-px flex-1 bg-gradient-to-r from-gold/40 to-transparent" />
                        </div>
                        <h3 className="mt-1.5 text-xl font-bold text-white">{s.title}</h3>
                        <p className="mt-1 text-sm leading-relaxed text-white/55">{s.text}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
