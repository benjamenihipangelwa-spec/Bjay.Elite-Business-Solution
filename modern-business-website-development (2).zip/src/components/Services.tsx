import { useState } from "react";
import {
  IconCode, IconApp, IconSheet, IconDoc, IconBolt, IconBrain,
  IconCompass, IconMegaphone, IconPalette, IconServer, IconWrench, IconBook,
  IconArrowRight, IconWhatsApp,
} from "./Icons";
import { BUSINESS, whatsappMessages } from "../utils/contact";

type Service = {
  title: string;
  short: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  items: string[];
  waMessage: string;
};

const services: Service[] = [
  {
    title: "Website Development",
    short: "Professional business websites built to convert and rank.",
    icon: IconCode,
    items: [
      "Static business websites", "Company websites", "Portfolio websites",
      "Landing pages", "Restaurant websites", "Booking websites",
      "E-commerce websites", "Business profile websites", "Website redesigns",
      "Mobile-responsive websites",
    ],
    waMessage: "Hello Bjay.Elite, I'd like a quotation for a website.\n\nBusiness:\nType of site:\nPages/Sections:\nFeatures:\nTimeline:",
  },
  {
    title: "Web Application Development",
    short: "Custom web apps and dashboards tailored to your operations.",
    icon: IconApp,
    items: [
      "Custom web applications", "Business management systems",
      "Customer management systems", "Booking systems", "Inventory systems",
      "Loan management systems", "Employee management systems",
      "Dashboard systems", "Online forms", "Database-powered applications",
    ],
    waMessage: "Hello Bjay.Elite, I'd like to enquire about a web application.\n\nType of system:\nRequired features:\nUsers (approx):\nTimeline:",
  },
  {
    title: "Excel & Business Systems",
    short: "Powerful spreadsheets with formulas, dashboards and reports.",
    icon: IconSheet,
    items: [
      "Accounting spreadsheets", "Cashbooks", "Loan management spreadsheets",
      "Stock/inventory systems", "Sales trackers", "Expense trackers",
      "Payroll spreadsheets", "Invoice systems", "Receipt systems",
      "Customer & employee registers", "Financial reports", "Monthly balancing",
      "Automated dashboards", "Business calculators",
    ],
    waMessage: whatsappMessages.excel,
  },
  {
    title: "Business Documents",
    short: "Polished, professional documents for any business need.",
    icon: IconDoc,
    items: [
      "Business plans", "Funding proposals", "Company profiles",
      "Quotations", "Invoices", "Receipts",
      "Reports", "Business policies", "Proposal documents",
      "Price lists", "Company letters", "Professional CVs", "Tender documents",
    ],
    waMessage: "Hello Bjay.Elite, I'd like a quotation for business documents.\n\nDocument(s) needed:\nPurpose:\nDeadline:",
  },
  {
    title: "Digital Automation",
    short: "Automate repetitive work and connect your tools.",
    icon: IconBolt,
    items: [
      "WhatsApp automation", "Email workflows", "Form automation",
      "Data collection", "Automated reports", "Business notifications",
      "Workflow automation", "AI-assisted business processes",
    ],
    waMessage: "Hello Bjay.Elite, I'd like to enquire about digital automation.\n\nProcess to automate:\nTools in use:\nGoal:",
  },
  {
    title: "AI Business Solutions",
    short: "Practical AI setups to give your business a modern edge.",
    icon: IconBrain,
    items: [
      "AI chatbot setup", "AI customer support concepts", "AI content creation",
      "AI business assistants", "AI document processing",
      "AI-powered workflow ideas", "AI consultation", "AI integration consulting",
    ],
    waMessage: "Hello Bjay.Elite, I'd like to explore an AI solution.\n\nWhat I'd like to achieve:\nCurrent tools:",
  },
  {
    title: "Business Consulting",
    short: "Strategic guidance for digital transformation and growth.",
    icon: IconCompass,
    items: [
      "Digital transformation", "Starting an online business", "Website planning",
      "Business system planning", "Digital marketing setup", "Technology selection",
      "Business process improvement", "Online presence development",
    ],
    waMessage: whatsappMessages.booking,
  },
  {
    title: "Digital Marketing Support",
    short: "Content and creatives that grow your online presence.",
    icon: IconMegaphone,
    items: [
      "Social media content", "Promotional posters", "Business flyers",
      "Social media captions", "Digital advertisements", "Brand presentation",
      "Online business presence",
    ],
    waMessage: "Hello Bjay.Elite, I'd like help with digital marketing.\n\nPlatforms:\nGoals:\nFrequency:",
  },
  {
    title: "Branding & Design",
    short: "Logos, identity kits and visuals that look premium.",
    icon: IconPalette,
    items: [
      "Business logos", "Business cards", "Flyers", "Posters",
      "Letterheads", "Digital banners", "Social media graphics",
      "Company branding packages",
    ],
    waMessage: "Hello Bjay.Elite, I'd like to enquire about branding.\n\nItems needed:\nBusiness name:\nStyle preferences:",
  },
  {
    title: "Website Hosting & Domain",
    short: "Domain, hosting, email and deployment guidance.",
    icon: IconServer,
    items: [
      "Domain selection", "Website hosting", "Deployment",
      "Website maintenance", "SSL setup", "Business email setup",
      "Website migration", "Hosting consultation",
    ],
    waMessage: whatsappMessages.hosting,
  },
  {
    title: "Website Maintenance",
    short: "Ongoing updates, fixes and improvements for your site.",
    icon: IconWrench,
    items: [
      "Content updates", "Image updates", "Website corrections",
      "Security/basic maintenance", "New sections", "Website improvements",
      "Technical support",
    ],
    waMessage: "Hello Bjay.Elite, I'd like to discuss website maintenance.\n\nCurrent site:\nRequired updates:",
  },
  {
    title: "Training & Digital Skills",
    short: "Practical training to help you manage your own systems.",
    icon: IconBook,
    items: [
      "Microsoft Excel", "Website management", "Basic web development",
      "Business systems", "Digital tools", "AI tools", "Online business tools",
    ],
    waMessage: "Hello Bjay.Elite, I'd like to enquire about training.\n\nTopic:\nFormat (online/in-person):",
  },
];

export default function Services() {
  const [expanded, setExpanded] = useState<number | null>(null);
  return (
    <section id="services" className="relative overflow-hidden bg-ink py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      <div className="pointer-events-none absolute -left-32 top-32 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />
      <div className="dotted-bg pointer-events-none absolute right-0 bottom-0 h-72 w-72 opacity-30" />

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-3xl text-center reveal">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            What We Do
          </div>
          <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl lg:text-5xl">
            Complete <span className="text-gold-gradient">digital</span> & business solutions
          </h2>
          <p className="mt-5 text-base leading-relaxed text-white/65 sm:text-lg">
            From websites and Excel systems to AI-powered automation and business consulting —
            we provide the digital backbone that helps modern businesses operate professionally.
          </p>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, idx) => {
            const Icon = s.icon;
            const isOpen = expanded === idx;
            const visible = isOpen ? s.items : s.items.slice(0, 5);
            return (
              <div
                key={s.title}
                className="reveal group relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-6 transition-all hover:border-gold/30 hover:shadow-2xl hover:shadow-gold/5"
              >
                <div className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full bg-gold/10 opacity-0 blur-2xl transition-opacity group-hover:opacity-100" />
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light/20 to-gold-dark/10 text-gold-light ring-1 ring-gold/20 transition-all group-hover:scale-105 group-hover:ring-gold/40">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 text-lg font-bold text-white">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/55">{s.short}</p>

                <ul className="mt-5 space-y-2">
                  {visible.map((it) => (
                    <li key={it} className="flex items-start gap-2 text-[13px] text-white/65">
                      <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-gold-light" />
                      <span>{it}</span>
                    </li>
                  ))}
                </ul>

                {s.items.length > 5 && (
                  <button
                    onClick={() => setExpanded(isOpen ? null : idx)}
                    className="mt-3 text-xs font-semibold text-gold-light hover:underline"
                  >
                    {isOpen ? "Show less" : `+ ${s.items.length - 5} more`}
                  </button>
                )}

                {s.title === "Excel & Business Systems" && (
                  <p className="mt-4 rounded-xl border border-gold/15 bg-gold/5 px-3 py-2 text-[11px] leading-relaxed text-gold-light/90">
                    Includes formulas, automated calculations, reports, dashboards, data
                    validation and professional formatting.
                  </p>
                )}

                <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
                  <a
                    href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(s.waMessage)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-light transition-all hover:gap-2.5"
                  >
                    <IconWhatsApp className="h-3.5 w-3.5" />
                    Get a quote
                  </a>
                  <a href="#contact" className="inline-flex items-center gap-1 text-xs text-white/40 hover:text-white">
                    Learn more
                    <IconArrowRight className="h-3 w-3" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Services CTA */}
        <div className="mt-16 reveal">
          <div className="relative overflow-hidden rounded-3xl border border-gold/20 bg-gradient-to-br from-[#15110a] to-[#0a0a0a] p-8 sm:p-12">
            <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-gold/15 blur-3xl" />
            <div className="pointer-events-none absolute -left-12 bottom-0 h-44 w-44 rounded-full bg-gold/10 blur-3xl" />
            <div className="relative flex flex-col items-center gap-6 text-center md:flex-row md:items-center md:justify-between md:text-left">
              <div className="max-w-2xl">
                <h3 className="text-2xl font-bold text-white sm:text-3xl">
                  Not sure what your business needs?
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-white/65 sm:text-base">
                  Tell us what you want to achieve and we will help you identify the right
                  digital solution — from a single website to a fully automated operation.
                </p>
              </div>
              <a
                href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(whatsappMessages.general)}`}
                target="_blank"
                rel="noreferrer"
                className="group inline-flex shrink-0 items-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-7 py-3.5 text-sm font-bold text-ink shadow-xl shadow-gold/20 transition-all hover:shadow-gold/40 hover:scale-[1.02]"
              >
                Talk to Bjay.Elite
                <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
