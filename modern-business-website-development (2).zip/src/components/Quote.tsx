import { BUSINESS, whatsappMessages } from "../utils/contact";
import { IconWhatsApp, IconArrowRight, IconSparkles } from "./Icons";

export default function Quote() {
  return (
    <section className="relative overflow-hidden bg-ink py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 hero-grid opacity-40" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />

      <div className="relative mx-auto max-w-5xl px-5 sm:px-8">
        <div className="reveal relative overflow-hidden rounded-3xl border border-gold/20 bg-gradient-to-br from-[#15110a] via-[#0e0c08] to-[#0a0a0a] p-8 sm:p-14">
          <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-gold/20 blur-3xl" />
          <div className="pointer-events-none absolute -left-12 -bottom-12 h-60 w-60 rounded-full bg-gold/10 blur-3xl" />

          <div className="relative flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-gold-light to-gold-dark text-ink shadow-xl shadow-gold/20">
              <IconSparkles className="h-7 w-7" />
            </div>
            <h2 className="mt-6 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl lg:text-5xl">
              Request a <span className="text-gold-gradient">custom quote</span>
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/65 sm:text-lg">
              Every business has different requirements. Contact Bjay.Elite with your project
              details and receive a customized quotation tailored to your needs and budget.
            </p>

            <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
              <a
                href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(whatsappMessages.general)}`}
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-7 py-3.5 text-sm font-bold text-ink shadow-xl shadow-gold/20 transition-all hover:shadow-gold/40 hover:scale-[1.02]"
              >
                <IconWhatsApp className="h-5 w-5" />
                Request a Quote
                <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-7 py-3.5 text-sm font-semibold text-white transition-all hover:border-gold-light/40 hover:bg-white/[0.08]"
              >
                Full Enquiry Form
              </a>
            </div>

            <div className="mt-12 grid w-full max-w-3xl gap-3 sm:grid-cols-3">
              {[
                ["Tell Us", "Briefly describe your project."],
                ["We Plan", "We propose the right solution."],
                ["You Receive", "A clear, tailored quotation."],
              ].map(([t, d]) => (
                <div key={t} className="rounded-2xl border border-white/5 bg-white/[0.03] p-4 text-left">
                  <div className="text-xs font-semibold uppercase tracking-wider text-gold-light">{t}</div>
                  <div className="mt-1 text-sm text-white/65">{d}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
