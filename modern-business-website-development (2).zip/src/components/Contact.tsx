import { useState } from "react";
import { BUSINESS, mailLink, whatsappMessages } from "../utils/contact";
import {
  IconWhatsApp, IconMail, IconPhone, IconMapPin,
  IconArrowRight, IconCheck, IconClock, IconServer,
} from "./Icons";
import { downloadHostingGuide } from "../utils/hostingGuidePdf";

const serviceOptions = [
  "Website Development",
  "Web Application",
  "Excel System",
  "Business Documents",
  "Automation",
  "AI Solutions",
  "Branding & Design",
  "Digital Marketing",
  "Hosting/Domain",
  "Consulting",
  "Other",
];

const budgetOptions = [
  "Under N$1,000",
  "N$1,000 – N$3,000",
  "N$3,000 – N$7,000",
  "N$7,000 – N$15,000",
  "N$15,000+",
  "To be discussed",
];

type C = {
  name: string; business: string; phone: string; email: string;
  service: string; budget: string; description: string;
};
const empty: C = { name: "", business: "", phone: "", email: "", service: "", budget: "", description: "" };

export default function Contact() {
  const [form, setForm] = useState<C>(empty);
  const [submitted, setSubmitted] = useState<"wa" | "email" | null>(null);

  const ok = form.name && form.phone && form.email && form.service;

  const msg = (extra = "") =>
    `Hello Bjay.Elite, I'd like to enquire about a project.\n\n- Name: ${form.name}\n- Business: ${form.business || "(not provided)"}\n- Phone: ${form.phone}\n- Email: ${form.email}\n- Service: ${form.service}\n- Budget: ${form.budget || "To be discussed"}\n- Description: ${form.description || "(not provided)"}${extra}`;

  const sendWA = () => {
    if (!ok) return;
    window.open(
      `https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(msg())}`,
      "_blank"
    );
    setSubmitted("wa");
  };

  const sendEmail = () => {
    if (!ok) return;
    window.location.href = mailLink("Project Enquiry — Bjay.Elite", msg());
    setSubmitted("email");
  };

  return (
    <section id="contact" className="relative overflow-hidden bg-ink py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      <div className="pointer-events-none absolute -left-40 bottom-0 h-80 w-80 rounded-full bg-gold/5 blur-3xl" />

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center reveal">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            Contact
          </div>
          <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
            Let's start your <span className="text-gold-gradient">project</span>
          </h2>
          <p className="mt-5 text-base leading-relaxed text-white/65">
            Tell us a little about what you need — we'll respond with the right next steps.
          </p>
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-12">
          {/* Contact details */}
          <div className="reveal lg:col-span-4">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-7">
              <h3 className="text-lg font-bold text-white">Contact details</h3>
              <p className="mt-1.5 text-sm text-white/55">
                Reach out via the channel you prefer.
              </p>

              <ul className="mt-7 space-y-4 text-sm">
                <li className="flex items-start gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold-light">
                    <IconWhatsApp className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-white/45">WhatsApp</div>
                    <a
                      href={`https://wa.me/${BUSINESS.whatsappRaw}`}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-0.5 block font-semibold text-white hover:text-gold-light"
                    >
                      {BUSINESS.whatsappDisplay}
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold-light">
                    <IconMail className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-white/45">Email</div>
                    <a
                      href={`mailto:${BUSINESS.email}`}
                      className="mt-0.5 block font-semibold text-white hover:text-gold-light break-all"
                    >
                      {BUSINESS.email}
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold-light">
                    <IconPhone className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-white/45">Phone</div>
                    <a
                      href={`tel:${BUSINESS.whatsappDisplay}`}
                      className="mt-0.5 block font-semibold text-white hover:text-gold-light"
                    >
                      {BUSINESS.whatsappDisplay}
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold-light">
                    <IconMapPin className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-white/45">Location</div>
                    <div className="mt-0.5 font-semibold text-white">{BUSINESS.location}</div>
                  </div>
                </li>
              </ul>

              <div className="mt-7 rounded-2xl border border-gold/20 bg-gold/5 p-4">
                <div className="flex items-start gap-3">
                  <IconClock className="mt-0.5 h-4 w-4 text-gold-light" />
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-gold-light">
                      Availability
                    </div>
                    <div className="mt-1 text-xs leading-relaxed text-white/65">
                      Mon – Fri: 08:00 – 18:00<br />
                      Sat: 09:00 – 14:00<br />
                      Sun: By appointment
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex flex-wrap gap-2">
                <a
                  href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(whatsappMessages.general)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-2.5 text-xs font-semibold text-white transition-all hover:scale-[1.02]"
                >
                  <IconWhatsApp className="h-4 w-4" />
                  WhatsApp
                </a>
                <a
                  href={mailLink("Enquiry — Bjay.Elite", "Hello Bjay.Elite,\n\nI'd like to enquire about a project.")}
                  className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-4 py-2.5 text-xs font-semibold text-white transition-all hover:border-gold-light/40"
                >
                  <IconMail className="h-4 w-4" />
                  Email
                </a>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="reveal lg:col-span-8">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-6 shadow-2xl sm:p-9">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold-dark text-ink shadow-lg shadow-gold/20">
                    <IconCheck className="h-8 w-8" />
                  </div>
                  <h3 className="mt-5 text-2xl font-bold text-white">Enquiry sent!</h3>
                  <p className="mt-3 max-w-md text-sm text-white/60">
                    {submitted === "wa"
                      ? "WhatsApp should have opened with your enquiry. Hit send to deliver it to our team."
                      : "Your email client should have opened with the enquiry details pre-filled. Hit send to deliver it."}
                  </p>
                  <button
                    onClick={() => { setSubmitted(null); setForm(empty); }}
                    className="mt-6 rounded-full border border-white/15 px-6 py-2 text-sm font-semibold text-white hover:border-gold-light/40"
                  >
                    Send another enquiry
                  </button>
                </div>
              ) : (
                <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <F label="Full Name *">
                      <input type="text" required className="form-input" placeholder="Full name"
                        value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                    </F>
                    <F label="Business Name">
                      <input type="text" className="form-input" placeholder="Business name (optional)"
                        value={form.business} onChange={(e) => setForm({ ...form, business: e.target.value })} />
                    </F>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <F label="Phone Number *">
                      <input type="tel" required className="form-input" placeholder="0812345678"
                        value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                    </F>
                    <F label="Email *">
                      <input type="email" required className="form-input" placeholder="you@example.com"
                        value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                    </F>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <F label="Service Required *">
                      <select required className="form-input"
                        value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })}>
                        <option value="">Select a service</option>
                        {serviceOptions.map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </F>
                    <F label="Budget Range">
                      <select className="form-input"
                        value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })}>
                        <option value="">Select a range</option>
                        {budgetOptions.map((b) => <option key={b} value={b}>{b}</option>)}
                      </select>
                    </F>
                  </div>

                  <F label="Project Description">
                    <textarea rows={5} className="form-input resize-none" placeholder="Describe what you'd like built..."
                      value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                  </F>

                  <div className="flex flex-col gap-3 pt-2 sm:flex-row">
                    <button
                      type="button"
                      disabled={!ok}
                      onClick={sendWA}
                      className="group inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-900/20 transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <IconWhatsApp className="h-5 w-5" />
                      Send via WhatsApp
                    </button>
                    <button
                      type="button"
                      disabled={!ok}
                      onClick={sendEmail}
                      className="group inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-6 py-3.5 text-sm font-bold text-ink shadow-lg shadow-gold/20 transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <IconMail className="h-5 w-5" />
                      Send via Email
                      <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </button>
                  </div>

                  {!ok && (
                    <p className="text-center text-xs text-white/45">
                      Please fill in name, phone, email and the service you need.
                    </p>
                  )}
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Free downloadable resources */}
        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          <div className="reveal relative overflow-hidden rounded-2xl border border-gold/20 bg-gradient-to-br from-[#15110a] to-[#0a0a0a] p-6 sm:p-7">
            <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gold/15 blur-3xl" />
            <div className="relative flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-ink shadow-lg shadow-gold/20">
                <IconServer className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-lg font-bold text-white">Free Hosting Guide (PDF)</h3>
                  <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                    Download
                  </span>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-white/65">
                  Step-by-step instructions for deploying this website on Netlify, Vercel,
                  GitHub Pages or Cloudflare Pages — including prerequisites, pros & cons,
                  and after-deployment tips.
                </p>
                <button
                  onClick={() => downloadHostingGuide()}
                  className="mt-5 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-5 py-2.5 text-sm font-bold text-ink shadow-lg shadow-gold/20 transition-all hover:scale-[1.02] hover:shadow-gold/40"
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                  </svg>
                  Download PDF Guide
                </button>
              </div>
            </div>
          </div>

          <div className="reveal relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-6 sm:p-7">
            <div className="relative flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gold/10 text-gold-light ring-1 ring-gold/20">
                <IconMail className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-bold text-white">Prefer we set it up?</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/65">
                  Bjay.Elite offers complete Website Hosting & Domain Consultation —
                  domain purchase, deployment, SSL and business email — handled end-to-end.
                </p>
                <a
                  href={`mailto:${BUSINESS.email}?subject=${encodeURIComponent("Hosting Setup — Bjay.Elite")}&body=${encodeURIComponent("Hello Bjay.Elite,\n\nI'd like you to host and set up my website.\n\nMy domain:\nCurrent state of project:")}`}
                  className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-sm font-semibold text-white transition-all hover:border-gold-light/40 hover:bg-white/[0.08]"
                >
                  Request Hosting Setup
                  <IconArrowRight className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function F({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-white/55">{label}</span>
      {children}
    </label>
  );
}
