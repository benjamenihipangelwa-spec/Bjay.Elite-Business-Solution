import { useState } from "react";
import { BUSINESS, mailLink } from "../utils/contact";
import { IconWhatsApp, IconMail, IconClock, IconArrowRight, IconCheck } from "./Icons";

const serviceOptions = [
  "Website Development",
  "Web Application",
  "Excel System",
  "Business Documents",
  "Automation",
  "AI Solutions",
  "Branding & Design",
  "Digital Marketing",
  "Hosting/Domain",
  "Consulting",
  "Other",
];

type BState = {
  name: string;
  phone: string;
  date: string;
  time: string;
  service: string;
  message: string;
};

const empty: BState = { name: "", phone: "", date: "", time: "", service: "", message: "" };

export default function Booking() {
  const [form, setForm] = useState<BState>(empty);
  const [submitted, setSubmitted] = useState<"wa" | "email" | null>(null);

  const requiredOk = form.name && form.phone && form.service;

  const buildMessage = (extra = "") =>
    `Hello Bjay.Elite, I'd like to book a consultation.\n\n- Name: ${form.name}\n- Phone: ${form.phone}\n- Service needed: ${form.service}\n- Preferred date: ${form.date || "Not specified"}\n- Preferred time: ${form.time || "Not specified"}\n- Message: ${form.message || "(none)"}${extra}`;

  const sendWA = () => {
    if (!requiredOk) return;
    window.open(
      `https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(buildMessage())}`,
      "_blank"
    );
    setSubmitted("wa");
  };

  const sendEmail = () => {
    if (!requiredOk) return;
    window.location.href = mailLink(
      "Consultation Booking — Bjay.Elite",
      buildMessage()
    );
    setSubmitted("email");
  };

  return (
    <section id="booking" className="relative overflow-hidden bg-[#0b0b0b] py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      <div className="pointer-events-none absolute -right-32 bottom-20 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-12 lg:items-start">
          <div className="lg:col-span-5 reveal">
            <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
              Book a Consultation
            </div>
            <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
              Schedule a <span className="text-gold-gradient">consultation</span>
            </h2>
            <p className="mt-5 text-base leading-relaxed text-white/65">
              Tell us when you're available and what you'd like to discuss. We'll confirm
              with you directly via WhatsApp or email.
            </p>

            <div className="mt-8 space-y-4">
              {[
                ["1. Fill the form", "Share a few details about your project."],
                ["2. Choose a channel", "Send via WhatsApp or email — whichever you prefer."],
                ["3. We confirm", "We'll respond and finalize a suitable time."],
              ].map(([t, d], i) => (
                <div key={t} className="flex gap-4 rounded-2xl border border-white/5 bg-white/[0.02] p-4">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold-dark text-sm font-bold text-ink">
                    {i + 1}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">{t}</div>
                    <div className="mt-0.5 text-xs text-white/55">{d}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 rounded-2xl border border-gold/20 bg-gold/5 p-5">
              <div className="flex items-start gap-3">
                <IconClock className="mt-0.5 h-5 w-5 text-gold-light" />
                <div>
                  <div className="text-sm font-semibold text-white">Operating Hours</div>
                  <div className="mt-1 text-xs leading-relaxed text-white/65">
                    Mon – Fri: 08:00 – 18:00 (CAT)<br />
                    Sat: 09:00 – 14:00<br />
                    Sun: By appointment
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 reveal">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-6 shadow-2xl sm:p-8">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold-dark text-ink shadow-lg shadow-gold/20">
                    <IconCheck className="h-8 w-8" />
                  </div>
                  <h3 className="mt-5 text-2xl font-bold text-white">Booking ready!</h3>
                  <p className="mt-3 max-w-md text-sm text-white/60">
                    {submitted === "wa"
                      ? "Your WhatsApp app should have opened with the booking details. Just send the message to confirm."
                      : "Your email app should have opened with the booking details pre-filled. Hit send to confirm."}
                  </p>
                  <button
                    onClick={() => { setSubmitted(null); setForm(empty); }}
                    className="mt-6 rounded-full border border-white/15 px-6 py-2 text-sm font-semibold text-white hover:border-gold-light/40"
                  >
                    Book another consultation
                  </button>
                </div>
              ) : (
                <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Your Name *">
                      <input
                        type="text"
                        required
                        placeholder="Full name"
                        className="form-input"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                      />
                    </Field>
                    <Field label="Phone *">
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 0812345678"
                        className="form-input"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      />
                    </Field>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Preferred Date">
                      <input
                        type="date"
                        className="form-input"
                        value={form.date}
                        onChange={(e) => setForm({ ...form, date: e.target.value })}
                      />
                    </Field>
                    <Field label="Preferred Time">
                      <input
                        type="time"
                        className="form-input"
                        value={form.time}
                        onChange={(e) => setForm({ ...form, time: e.target.value })}
                      />
                    </Field>
                  </div>

                  <Field label="Service Needed *">
                    <select
                      required
                      className="form-input"
                      value={form.service}
                      onChange={(e) => setForm({ ...form, service: e.target.value })}
                    >
                      <option value="">Select a service</option>
                      {serviceOptions.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </Field>

                  <Field label="Message">
                    <textarea
                      rows={4}
                      placeholder="Briefly describe what you'd like to discuss..."
                      className="form-input resize-none"
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                    />
                  </Field>

                  <div className="flex flex-col gap-3 pt-2 sm:flex-row">
                    <button
                      type="button"
                      disabled={!requiredOk}
                      onClick={sendWA}
                      className="group inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-900/20 transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <IconWhatsApp className="h-5 w-5" />
                      Book via WhatsApp
                    </button>
                    <button
                      type="button"
                      disabled={!requiredOk}
                      onClick={sendEmail}
                      className="group inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold-light to-gold-dark px-6 py-3.5 text-sm font-bold text-ink shadow-lg shadow-gold/20 transition-all hover:scale-[1.01] disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <IconMail className="h-5 w-5" />
                      Book via Email
                      <IconArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </button>
                  </div>

                  {!requiredOk && (
                    <p className="text-center text-xs text-white/45">
                      Please fill in your name, phone and service to continue.
                    </p>
                  )}
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-white/55">{label}</span>
      {children}
    </label>
  );
}
