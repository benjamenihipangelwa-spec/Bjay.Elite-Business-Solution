import { useState } from "react";
import { IconArrowRight, IconWhatsApp, IconEye } from "./Icons";
import { BUSINESS } from "../utils/contact";

type Item = {
  title: string;
  category: string;
  description: string;
  image: string;
  type: string;
};

const items: Item[] = [
  {
    title: "Corporate Business Website",
    category: "Websites",
    description: "Modern multi-page corporate website with services, team and contact sections.",
    image: "/images/portfolio-1.jpg",
    type: "Website Mockup",
  },
  {
    title: "Accounting Excel System",
    category: "Excel Systems",
    description: "Comprehensive Excel accounting system with formulas, dashboards and monthly reports.",
    image: "/images/portfolio-2.jpg",
    type: "Excel Dashboard",
  },
  {
    title: "Inventory Management System",
    category: "Business Systems",
    description: "Web-based inventory tracking system with supplier and stock movement reports.",
    image: "/images/portfolio-3.jpg",
    type: "Web Application",
  },
  {
    title: "Premium Brand Identity",
    category: "Branding",
    description: "Full brand identity including logo, letterhead, business card and social media kit.",
    image: "/images/portfolio-4.jpg",
    type: "Branding Package",
  },
  {
    title: "WhatsApp Business Automation",
    category: "Digital Solutions",
    description: "Automated WhatsApp responses, lead capture and notification workflows.",
    image: "/images/portfolio-5.jpg",
    type: "Automation Flow",
  },
  {
    title: "AI Customer Assistant",
    category: "Digital Solutions",
    description: "Custom AI assistant setup for handling enquiries and customer support.",
    image: "/images/portfolio-6.jpg",
    type: "AI Solution",
  },
];

const categories = ["All", "Websites", "Excel Systems", "Business Systems", "Branding", "Digital Solutions"];

export default function Portfolio() {
  const [filter, setFilter] = useState<string>("All");
  const filtered = filter === "All" ? items : items.filter((i) => i.category === filter);

  return (
    <section id="portfolio" className="relative overflow-hidden bg-[#0b0b0b] py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      <div className="pointer-events-none absolute -left-40 bottom-20 h-72 w-72 rounded-full bg-gold/5 blur-3xl" />

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center reveal">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            Portfolio
          </div>
          <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
            Sample <span className="text-gold-gradient">solutions</span> we build
          </h2>
          <p className="mt-5 text-base leading-relaxed text-white/65">
            Below are representative samples of the kind of digital solutions Bjay.Elite
            delivers. Contact us to request something similar for your business.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-2 reveal">
          {categories.map((c) => {
            const active = filter === c;
            return (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`rounded-full border px-4 py-2 text-xs font-semibold transition-all ${
                  active
                    ? "border-gold-light bg-gradient-to-r from-gold-light to-gold-dark text-ink shadow-md shadow-gold/20"
                    : "border-white/10 bg-white/[0.02] text-white/60 hover:border-gold/30 hover:text-white"
                }`}
              >
                {c}
              </button>
            );
          })}
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((it, i) => (
            <div
              key={it.title + i}
              className="reveal group relative overflow-hidden rounded-2xl border border-white/5 bg-white/[0.02]"
            >
              <div className="relative h-56 overflow-hidden sm:h-60">
                <img
                  src={it.image}
                  alt={it.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
                <span className="absolute left-4 top-4 rounded-full border border-gold/30 bg-black/50 px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-gold-light backdrop-blur">
                  {it.category}
                </span>
                <div className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white/70 backdrop-blur transition-all group-hover:bg-gold-light group-hover:text-ink">
                  <IconEye className="h-4 w-4" />
                </div>
              </div>
              <div className="p-5">
                <div className="text-[11px] uppercase tracking-wider text-white/40">{it.type}</div>
                <h3 className="mt-1 text-lg font-bold text-white">{it.title}</h3>
                <p className="mt-2 line-clamp-2 text-sm text-white/55">{it.description}</p>
                <div className="mt-5 flex items-center justify-between gap-2 border-t border-white/5 pt-4">
                  <a
                    href={`https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(
                      `Hello Bjay.Elite, I'd like to request a solution similar to "${it.title}".`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-full bg-gold/10 px-3 py-1.5 text-xs font-semibold text-gold-light transition-all hover:bg-gold-light hover:text-ink"
                  >
                    <IconWhatsApp className="h-3.5 w-3.5" />
                    Request Similar
                  </a>
                  <a href="#contact" className="inline-flex items-center gap-1 text-xs font-semibold text-white/55 transition-colors hover:text-white">
                    View Project
                    <IconArrowRight className="h-3 w-3" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-8 text-center text-xs text-white/40">
          * Portfolio samples shown are mockups and design representations for demonstration purposes.
        </p>
      </div>
    </section>
  );
}
