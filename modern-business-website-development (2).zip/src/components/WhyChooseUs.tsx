import { IconWrench, IconDollar, IconSparkles, IconUsers } from "./Icons";

const reasons = [
  {
    icon: IconWrench,
    title: "Custom Solutions",
    text: "Every solution is designed around the client's requirements — no one-size-fits-all.",
  },
  {
    icon: IconDollar,
    title: "Affordable",
    text: "Practical digital solutions for individuals, startups and growing businesses.",
  },
  {
    icon: IconSparkles,
    title: "Professional",
    text: "Clean, modern and business-focused results built to a high standard.",
  },
  {
    icon: IconUsers,
    title: "Support",
    text: "We help clients understand and use the solutions we create.",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="relative overflow-hidden bg-[#0b0b0b] py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center reveal">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold/20 bg-gold/5 px-4 py-1.5 text-xs font-medium text-gold-light">
            Why Choose Us
          </div>
          <h2 className="mt-5 text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
            Built around <span className="text-gold-gradient">your business</span>
          </h2>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {reasons.map((r, i) => {
            const Icon = r.icon;
            return (
              <div
                key={r.title}
                className="reveal lift-card relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.04] to-transparent p-6"
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-gold/10 opacity-50 blur-2xl" />
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-gold-light to-gold-dark text-ink shadow-lg shadow-gold/10">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-5 text-lg font-bold text-white">{r.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/55">{r.text}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
