// Comprehensive knowledge base extracted directly from the website content.
// The chatbot answers ONLY from this knowledge base and will not make up information.

export const KNOWLEDGE_BASE: { patterns: RegExp[]; answer: string; keywords?: string[] }[] = [
  {
    keywords: ["website", "build website", "make website", "create website", "web development", "site"],
    patterns: [
      /\bwebsite(s)?\b/i,
      /\bweb\s*dev(elo?pment)?\b/i,
      /\b(build|make|create|design)\s+(a|me|my)?\s*website/i,
      /\b(static|business|company|portfolio|landing|restaurant|booking|e-?commerce|profile)\s*(website|site)/i,
    ],
    answer: "Yes. We create professional websites for businesses, individuals, startups and organizations — including static business websites, company websites, portfolio websites, landing pages, restaurant websites, booking websites, e-commerce websites, business profile websites, website redesigns and mobile-responsive websites. Send a project request via the Contact section or chat with us on WhatsApp for a quote.",
  },
  {
    keywords: ["web application", "web app", "system", "management system"],
    patterns: [
      /\bweb\s*app(lication)?s?\b/i,
      /\bmanagement\s*system/i,
      /\binventory\s*system/i,
      /\bbooking\s*system/i,
      /\b(loan|employee|customer)\s*management/i,
    ],
    answer: "Yes. We build customized web applications and business systems including business management systems, customer management systems, booking systems, inventory systems, loan management systems, employee management systems, dashboard systems, online forms and database-powered applications — all tailored to your operations. Get a quote via the Contact form.",
  },
  {
    keywords: ["excel", "spreadsheet", "cashbook", "accounting", "payroll"],
    patterns: [
      /\bexcel\b/i,
      /\bspreadsheet(s)?\b/i,
      /\bcashbook\b/i,
      /\baccounting\b/i,
      /\bpayroll\b/i,
      /\b(invoice|receipt)\s*system\b/i,
    ],
    answer: "Yes. We create customized Excel spreadsheets with formulas, automated calculations, reports, dashboards, data validation and professional formatting. Available systems include accounting spreadsheets, cashbooks, loan management spreadsheets, stock/inventory systems, sales trackers, expense trackers, payroll spreadsheets, invoice systems, receipt systems, customer & employee registers, financial reports, monthly balancing systems, automated dashboards and business calculators. Request a quote in the Contact section.",
  },
  {
    keywords: ["document", "business plan", "proposal", "cv", "letter"],
    patterns: [
      /\bbusiness\s*plan\b/i,
      /\bfunding\s*proposal/i,
      /\bcompany\s*profile/i,
      /\bquotation(s)?\b/i,
      /\b(invoice|receipt|reports?|polic(y|ies)|proposal|price\s*list|letter|tender|cv)s?\b/i,
    ],
    answer: "Yes. We professionally prepare business plans, funding proposals, company profiles, quotations, invoices, receipts, reports, business policies, proposal documents, price lists, company letters, professional CVs and tender documents. Send your requirements through the Contact form or via WhatsApp.",
  },
  {
    keywords: ["automation", "automate", "workflow"],
    patterns: [
      /\bautomation\b/i,
      /\bautomate\w*/i,
      /\bworkflow/i,
      /\bwhatsapp\s*automation/i,
    ],
    answer: "Yes. Our digital automation services include WhatsApp automation, email workflows, form automation, data collection, automated reports, business notifications, workflow automation and AI-assisted business processes. Send us your requirements to plan the right automation.",
  },
  {
    keywords: ["ai", "chatbot", "artificial intelligence"],
    patterns: [
      /\bai\b/i,
      /\bartificial\s*intelligence/i,
      /\bchatbot/i,
      /\bai\s*(chatbot|solution|assistant|integration|consult)/i,
    ],
    answer: "Yes. Our AI business solutions include AI chatbot setup, AI customer support concepts, AI content creation, AI business assistants, AI document processing, AI-powered workflow ideas, AI consultation and AI integration consulting. Reach out to discuss what's possible for your business.",
  },
  {
    keywords: ["consult", "consulting", "advice", "transformation"],
    patterns: [
      /\bconsult(ing|ation)?\b/i,
      /\bdigital\s*transform/i,
      /\b(start|starting)\s*(an|a|online)?\s*business/i,
      /\bbusiness\s*advice\b/i,
    ],
    answer: "Yes. We provide digital and technology-focused business consulting including digital transformation, starting an online business, website planning, business system planning, digital marketing setup, technology selection, business process improvement and online presence development. Book a consultation through the Booking section.",
  },
  {
    keywords: ["branding", "logo", "design", "business card"],
    patterns: [
      /\bbranding\b/i,
      /\blogo(s)?\b/i,
      /\bbusiness\s*card(s)?\b/i,
      /\b(letterhead|poster|flyer|banner|graphic|branding\s*package)/i,
    ],
    answer: "Yes. Our branding & design services include business logos, business cards, flyers, posters, letterheads, digital banners, social media graphics and full company branding packages.",
  },
  {
    keywords: ["marketing", "social media", "content", "advert"],
    patterns: [
      /\b(social\s*media|digital)\s*marketing/i,
      /\b(promotional\s*)?poster(s)?\b/i,
      /\bflyer(s)?\b/i,
      /\bcaption(s)?\b/i,
      /\b(digital\s*)?advert(isement)?s?\b/i,
    ],
    answer: "Yes. We provide digital marketing support including social media content, promotional posters, business flyers, social media captions, digital advertisements, brand presentation and online business presence support.",
  },
  {
    keywords: ["hosting", "domain", "deployment", "ssl", "email setup", "migration"],
    patterns: [
      /\b(hosting|domain|deployment|ssl|migration)/i,
      /\bwebsite\s*(hosting|maintenance)/i,
      /\bbusiness\s*email/i,
    ],
    answer: "Yes. We assist with domain selection, website hosting, deployment, website maintenance, SSL setup, business email setup, website migration and hosting consultation. Chat with us on WhatsApp for hosting/domain enquiries.",
  },
  {
    keywords: ["maintenance", "update", "fix"],
    patterns: [
      /\bwebsite\s*maintenance/i,
      /\b(content|image|security)\s*update/i,
      /\bwebsite\s*(fix|correction|improvement)/i,
    ],
    answer: "Yes. Our website maintenance covers content updates, image updates, website corrections, security/basic maintenance, new sections, website improvements and ongoing technical support.",
  },
  {
    keywords: ["training", "learn", "course", "tutorial"],
    patterns: [
      /\btraining\b/i,
      /\b(digital|online)\s*skills?/i,
      /\b(learn|teach|tutor)\b/i,
    ],
    answer: "Yes. We offer practical training and consultation in Microsoft Excel, website management, basic web development, business systems, digital tools, AI tools and online business tools. Send a message to discuss your training needs.",
  },
  {
    keywords: ["price", "pricing", "cost", "how much", "quote", "quotation"],
    patterns: [
      /\b(price(ing)?|cost|fee|charge(?!r)|how much|quote|quotation)\b/i,
      /\bbudget\b/i,
    ],
    answer: "Every business has different requirements, so we don't display fixed prices. Contact us through WhatsApp or email with your project details and you'll receive a customized quotation tailored to your needs and budget. Use the Contact form to send your requirements.",
  },
  {
    keywords: ["whatsapp", "chat", "message"],
    patterns: [/\bwhatsapp\b/i, /\bchat\b/i],
    answer: "You can reach us on WhatsApp at +264 81 472 2735. The floating green WhatsApp button on this site will open a chat with us directly. You can also use the pre-filled WhatsApp links in the Services, Portfolio and Booking sections.",
  },
  {
    keywords: ["email", "mail"],
    patterns: [/\bemail\b/i, /\bmail\s*to/i, /@[a-z]/i],
    answer: "Our email is b.jayrna@gmail.com. You can click the email buttons across the site or use the Contact / Booking form to send your enquiry directly through your email application.",
  },
  {
    keywords: ["phone", "number", "call", "telephone"],
    patterns: [/\bphone\b/i, /\b(call|tel|number|reach( you| us)?)\b/i],
    answer: "Our phone / WhatsApp number is +264 81 472 2735. We're based in Namibia. For the fastest response, we recommend WhatsApp.",
  },
  {
    keywords: ["location", "where", "address", "country", "based"],
    patterns: [/\b(where|address|location|based|country)\b/i, /\bnamibia\b/i, /\bphysical/i],
    answer: "Bjay.Elite Business Solutions is based in Namibia and serves clients locally and beyond. We don't publish a physical street address — please use WhatsApp or email for all enquiries.",
  },
  {
    keywords: ["hours", "open", "available", "schedule"],
    patterns: [/\b(hours|open|time|schedule|available|when)\b/i, /\bbusiness\s*hours/i],
    answer: "Our typical hours are Mon – Fri: 08:00 – 18:00 (CAT), Sat: 09:00 – 14:00, Sun: By appointment. You can send a message anytime via WhatsApp or email and we'll respond as soon as possible.",
  },
  {
    keywords: ["consultation", "book", "meeting", "appointment"],
    patterns: [/\b(consultation|book|booking|meeting|appointment|schedule)\b/i],
    answer: "Yes. Use the 'Book a Consultation' section on this site — fill in your name, phone, preferred date/time, service and a short message, then send it via WhatsApp or email. We'll confirm with you directly.",
  },
  {
    keywords: ["about", "who", "company", "bjay", "elite", "what is"],
    patterns: [/\b(about|who|what\s*is|company|bjay( ?\.?elite)?|elite)\b/i],
    answer: "Bjay.Elite Business Solutions helps individuals and businesses turn ideas into practical digital solutions. From professional websites and customized Excel systems to business documents, automation and digital consulting, we provide solutions tailored to each client's needs. Our tagline is “Smart Digital Solutions for Businesses.”",
  },
  {
    keywords: ["services", "offer", "what do you do", "provide"],
    patterns: [/\b(what\s*(do)?\s*you\s*(do|offer)|services?|offer|provide)\b/i, /help\s*with/i],
    answer: "We offer Website Development, Web Application Development, Excel & Business Systems, Business Documents, Digital Automation, AI Business Solutions, Business Consulting, Digital Marketing Support, Branding & Design, Website Hosting & Domain Consultation, Website Maintenance, and Training & Digital Skills. Tap any service card on the Services section to send us a WhatsApp quote request.",
  },
  {
    keywords: ["process", "steps", "how do you work", "workflow"],
    patterns: [/\bprocess\b/i, /\bhow\s*do\s*you\s*work/i, /\bsteps?\b/i],
    answer: "Our 5-step process is: 01 Discover — discuss your needs and goals; 02 Plan — recommend the right solution; 03 Build — develop and customize; 04 Test — check functionality, responsiveness and quality; 05 Deliver — launch and provide guidance/support.",
  },
  {
    keywords: ["portfolio", "work", "samples", "examples", "previous"],
    patterns: [/\b(portfolio|work|samples?|examples?|previous(\s*work)?|projects?)\b/i],
    answer: "You can view sample work in the Portfolio section — it includes websites, Excel systems, business systems, branding and digital solutions. Tap “Request Similar” on any item to send us a WhatsApp enquiry about building something similar.",
  },
  {
    keywords: ["blog", "article", "news"],
    patterns: [/\b(blog|article|news|post)\b/i],
    answer: "This site doesn't currently have a blog. For updates and to learn about our services, you can follow our social channels (placeholders are in the footer) or contact us directly via WhatsApp.",
  },
];

// Fallback when no match is found — explicitly says we don't have the info on the site.
export const FALLBACK_ANSWER =
  "I don't have that specific information on this website. For a detailed answer, please reach out directly via WhatsApp at +264 81 472 2735 or email b.jayrna@gmail.com — we'll be happy to help.";

// Check whether any pattern in the knowledge base matches the user's input
export function findAnswer(input: string): string | null {
  const text = input.trim();
  if (!text) return null;

  // Direct keyword match (cheapest path)
  const lower = text.toLowerCase();
  for (const entry of KNOWLEDGE_BASE) {
    if (entry.keywords && entry.keywords.some((k) => lower.includes(k))) {
      // Verify at least one pattern also matches to avoid false positives
      if (entry.patterns.some((p) => p.test(text))) return entry.answer;
    }
  }

  // Pattern match
  for (const entry of KNOWLEDGE_BASE) {
    if (entry.patterns.some((p) => p.test(text))) return entry.answer;
  }

  return null;
}

// Suggested quick-replies that the visitor can click
export const SUGGESTED_QUESTIONS = [
  "Do you build websites?",
  "Do you create Excel systems?",
  "What services do you offer?",
  "How do I get a quotation?",
  "How can I contact you?",
  "What is your process?",
];
