// Centralized contact details & WhatsApp helpers
export const BUSINESS = {
  name: "Bjay.Elite Business Solutions",
  tagline: "Smart Digital Solutions for Businesses.",
  whatsappRaw: "264814722735",
  whatsappDisplay: "+264 81 472 2735",
  email: "b.jayrna@gmail.com",
  location: "Namibia",
  socials: {
    facebook: "#",
    instagram: "#",
    tiktok: "#",
    linkedin: "#",
  },
};

export const waLink = (message: string) =>
  `https://wa.me/${BUSINESS.whatsappRaw}?text=${encodeURIComponent(message)}`;

export const mailLink = (subject: string, body: string) =>
  `mailto:${BUSINESS.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

export const whatsappMessages = {
  general: `Hello Bjay.Elite, I would like to enquire about your digital solutions.`,
  website: `Hello Bjay.Elite, I'd like to request a quotation for a website. Here are the details:\n\n- Business:\n- Pages/Sections needed:\n- Preferred features:\n- Timeline:`,
  excel: `Hello Bjay.Elite, I'd like to request a quotation for an Excel system. Here are the details:\n\n- Type of system (accounting, stock, payroll, etc.):\n- Required features:\n- Data volume (approx):\n- Timeline:`,
  booking: `Hello Bjay.Elite, I'd like to book a consultation. Here are my details:\n\n- Name:\n- Phone:\n- Service needed:\n- Preferred date:\n- Preferred time:\n- Brief description:`,
  hosting: `Hello Bjay.Elite, I'd like to enquire about domain/hosting services.`,
};
