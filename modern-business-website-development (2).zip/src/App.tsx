import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import WhyChooseUs from "./components/WhyChooseUs";
import Process from "./components/Process";
import Portfolio from "./components/Portfolio";
import Quote from "./components/Quote";
import WhatsAppConsult from "./components/WhatsAppConsult";
import Booking from "./components/Booking";
import Contact from "./components/Contact";
import FAQ from "./components/FAQ";
import Footer from "./components/Footer";
import FloatingWhatsApp from "./components/FloatingWhatsApp";
import Chatbot from "./components/Chatbot";
import { useReveal } from "./utils/useReveal";

export default function App() {
  useReveal();

  return (
    <div className="min-h-screen bg-ink text-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <WhyChooseUs />
        <Process />
        <Portfolio />
        <Quote />
        <WhatsAppConsult />
        <Booking />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
      <Chatbot />
    </div>
  );
}
