# 🛠️ DEVELOPER HANDOVER NOTES

This document is written specifically for the developer taking over this project.
Read it once carefully before starting — it covers everything needed to host the
**Bjay.Elite Business Solutions** website on the client's domain.

---

## 📦 What You're Receiving

A complete, ready-to-deploy static website built with **React 19 + Vite 7 + Tailwind CSS v4 + TypeScript**. The site is **100% static** — there is no backend, no database, no API to configure, no environment variables. Hosting is just uploading files.

---

## ⏱️ Estimated Time to Go Live

- **Reading handover & building locally:** 15 minutes
- **Deploying to a host:** 5–10 minutes
- **Connecting a custom domain:** 5–30 minutes (depends on DNS propagation)
- **Total:** ~30 minutes

---

## 🎯 The 5-Minute Summary (TL;DR)

```bash
# 1. Install dependencies
npm install

# 2. Verify it builds & runs locally
npm run build
npm run preview          # serves the built site at http://localhost:4173

# 3. Deploy the /dist folder to ANY static host:
#    - Netlify (drag & drop at netlify.com/drop)
#    - Vercel (vercel.com → New Project → import)
#    - Cloudflare Pages (pages.cloudflare.com)
#    - GitHub Pages
#    - Or any traditional web host via FTP/cPanel

# 4. Point the client's domain to the host (DNS A or CNAME record)
# 5. Done — site is live at https://theirdomain.com
```

That's it. There's nothing more to configure.

---

## 📁 Files in This Package

| File / Folder | Purpose |
|--------------|---------|
| `src/` | All React source code |
| `public/` | Static assets (favicon, hero image, portfolio mockups) |
| `index.html` | HTML entry (title, meta tags, Open Graph, fonts) |
| `package.json` | Dependencies + npm scripts |
| `tsconfig.json` | TypeScript configuration |
| `vite.config.ts` | Vite configuration (single-file output) |
| `README.md` | Project documentation |
| `HANDOVER.md` | **This file — read it first** |
| `dist/` | ⭐ **Production-ready built site — upload this to the host** |

After running `npm run build`, the entire deployable site is in **`dist/`**. The build also generates a single self-contained `dist/index.html` with all CSS and JS inlined, plus an `images/` folder. **This is the only thing the host needs.**

---

## 🔧 Environment Requirements

- **Node.js 18 or higher** (Node 20 LTS recommended)
- **npm 9+** (bundled with Node 18+)

To check:
```bash
node --version    # should be v18.x or higher
npm --version
```

No other system tools, no PHP, no MySQL, no Apache, no Docker.

---

## 🚀 Deployment Walkthroughs

### Option A — Netlify (Easiest, Recommended)

**Best for:** fastest setup, free HTTPS, free hosting on a `.netlify.app` subdomain.

1. Open **https://app.netlify.com** and sign up (free).
2. Once logged in: **Add new site → Deploy manually**.
3. On your computer, locate the `dist` folder inside this project (created by `npm run build`).
4. **Drag the entire `dist` folder** onto the Netlify upload area.
5. Wait ~30 seconds. Site is live at `https://random-name.netlify.app`.
6. **Add the client's custom domain:**
   - Click the deployed site → **Domain settings** → **Add custom domain**
   - Enter `bjayelite.com.na` (or whatever domain the client owns)
   - Netlify will show you the DNS records to add at the registrar.
7. **Update DNS at the domain registrar** (e.g. AfriHOST, Namecheap):
   - If using a subdomain (`www.bjayelite.com.na`): add a **CNAME** record pointing to the Netlify target.
   - If using the root domain (`bjayelite.com.na`): add the **A records** Netlify provides, or use Netlify DNS.
8. Back in Netlify, click **"Verify DNS"** and enable **"Force HTTPS"** (free SSL certificate auto-issues within minutes).
9. Done. The site is live at the client's domain with HTTPS.

### Option B — Vercel

1. Push the project code to GitHub (optional but recommended).
2. Sign up at **vercel.com**.
3. Click **Add New → Project** and import the GitHub repo.
4. Vercel auto-detects Vite. Confirm:
   - Build command: `npm run build`
   - Output directory: `dist`
5. Click **Deploy**. Live in ~30s.
6. Add custom domain in **Settings → Domains** and follow the DNS instructions.

### Option C — Cloudflare Pages (Best Performance)

1. Sign up at **pages.cloudflare.com**.
2. **Create a project → Connect to Git** (or upload `dist` via direct upload).
3. Build settings:
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Build output directory: `dist`
4. **Save and Deploy**.
5. Add custom domain under **Custom domains**.
6. (Recommended) Update nameservers at the registrar to Cloudflare's — this unlocks the full CDN.

### Option D — Traditional Hosting via FTP/cPanel

If the client has purchased hosting from a Namibian provider (e.g. AfriHOST) or a cPanel-based host:

1. Get FTP credentials from the client (host, username, password).
2. Use **FileZilla** or any FTP client.
3. Upload the **contents** of the `dist` folder (not the folder itself) to the web root:
   - For a root domain: upload to `public_html/`
   - For a subdomain: upload to `public_html/subdomain/`
4. Make sure `index.html` is at the root of where you uploaded.
5. Visit the domain. It should work immediately.

**Important:** If the site uses a client-side router (this one doesn't — it uses anchor links), you'd need to configure rewrites. Since this site is a single page with `<a href="#section">` anchors, **no rewrite configuration is needed.**

---

## 🌐 Connecting the Client's Domain

The client owns a domain (likely through AfriHOST, Namecheap or another registrar).
They need to:

1. Log into their domain registrar account.
2. Find the **DNS Management** section.
3. Add the records shown by the chosen host (Netlify / Vercel / Cloudflare will give exact values).

Common scenarios:

**Using Netlify DNS (simplest):**
- At the registrar, change nameservers to:
  - `dns1.p01.nsone.net`
  - `dns2.p01.nsone.net`
  - `dns3.p01.nsone.net`
  - `dns4.p01.nsone.net`
- Then add the domain in Netlify — it auto-configures everything.

**Using an external DNS provider:**
- Add the **A record** or **CNAME** provided by Netlify/Vercel/Cloudflare.
- DNS propagation can take 5 minutes to 48 hours (usually under 30 minutes).

---

## ✅ Acceptance Checklist (before handing back to the client)

- [ ] Site loads at the client's domain with `https://`
- [ ] Browser shows the **padlock icon** (SSL is active)
- [ ] Navbar links scroll smoothly to each section
- [ ] All WhatsApp buttons open WhatsApp with the correct message
- [ ] All email buttons open the default mail client with pre-filled content
- [ ] The BjayBot chatbot (bottom-left) opens and answers questions
- [ ] The "Download Hosting Guide" button in the footer downloads a PDF
- [ ] The floating WhatsApp button (bottom-right) works on mobile and desktop
- [ ] Site is responsive at 375px (iPhone SE), 768px (iPad) and 1440px (desktop)
- [ ] No console errors in the browser DevTools

---

## 🆘 Common Issues & Fixes

**Issue:** Site loads but CSS looks broken (no styles applied)
**Fix:** The host is serving the raw source files instead of the built `dist/` folder. Re-upload the contents of `dist/`, not `src/`.

**Issue:** "Cannot find module" errors during `npm install`
**Fix:** Use Node 18+ and delete `node_modules` + `package-lock.json`, then re-run `npm install`.

**Issue:** Domain shows "Not Secure"
**Fix:** Wait a few minutes for SSL to provision, or click "Force HTTPS" in the host's dashboard.

**Issue:** WhatsApp link opens to a wrong number
**Fix:** Check `src/utils/contact.ts` — both `whatsappRaw` and `whatsappDisplay` must be set correctly.

**Issue:** Need to update the site later
**Fix:** Make code edits → run `npm run build` → re-upload the new `dist/` folder to the host.

---

## 📞 Client Contact (for the developer)

If you need clarification from the client:

- **WhatsApp / Phone:** +264 81 472 2735
- **Email:** b.jayrna@gmail.com
- **Location:** Namibia

---

## 📂 Final Summary

This is a complete, self-contained, production-ready project. The client wants you to:
1. ✅ Take the source code as-is (don't rebuild from scratch — use these files)
2. ✅ Connect the client's domain
3. ✅ Deploy the built `dist/` folder
4. ✅ Confirm HTTPS works
5. ✅ Hand back access to the deployed site

**No additional development is required unless the client requests changes.**

---

© 2026 Bjay.Elite Business Solutions. All Rights Reserved.
