# Bjay.Elite Business Solutions — Website

A premium static business website for **Bjay.Elite Business Solutions** — "Smart Digital Solutions for Businesses."

This project is a complete, production-ready static site built with **React + Vite + Tailwind CSS v4**. It has no backend, no database and no server-side code — just files your developer can deploy to any static host.

---

## 📋 Project Overview for Your Developer

**Client:** Bjay.Elite Business Solutions
**Purpose:** Static business website (services presentation + lead generation)
**Stack:**
- React 19 (functional components, hooks)
- Vite 7 (build tool)
- Tailwind CSS 4 (utility-first styling)
- TypeScript
- jsPDF (client-side PDF generator for the downloadable Hosting Guide)

**Output type:** 100% static — single `index.html` with inlined JS + CSS, optimized images, no server needed.

---

## 🚀 Quick Start (for the developer)

```bash
# 1. Install dependencies (first time only)
npm install

# 2. Start the local development server
npm run dev
# → Site opens at http://localhost:5173

# 3. Build for production
npm run build
# → Optimized output goes to /dist
```

The `dist` folder is **the entire deployable site**. Upload its contents (or the folder itself) to any static host — that's it.

---

## 🌐 Recommended Hosting Platforms (any one works)

| Platform | Difficulty | Cost | Notes |
|----------|-----------|------|-------|
| **Netlify** ⭐ | Easy | Free tier | Drag-and-drop the `dist` folder at netlify.com/drop |
| **Vercel** | Easy | Free tier | Best for Git-based deployments |
| **Cloudflare Pages** | Medium | Free tier | Best global performance |
| **GitHub Pages** | Medium | Free | Good if code is already on GitHub |

Detailed step-by-step instructions are in **`HANDOVER.md`** and also downloadable as a PDF from the live site itself.

---

## 📁 Project Structure

```
.
├── public/                      # Static assets (favicon, hero/portfolio images)
│   ├── favicon.svg
│   └── images/
│       ├── hero.jpg
│       ├── about.jpg
│       └── portfolio-1.jpg … portfolio-6.jpg
├── src/                         # Application source code
│   ├── App.tsx                  # Main entry — composes all sections
│   ├── main.tsx                 # React mount point
│   ├── index.css                # Tailwind + custom design tokens + animations
│   ├── components/              # All UI sections, one per file
│   │   ├── Navbar.tsx
│   │   ├── Hero.tsx
│   │   ├── About.tsx
│   │   ├── Services.tsx
│   │   ├── WhyChooseUs.tsx
│   │   ├── Process.tsx
│   │   ├── Portfolio.tsx
│   │   ├── Quote.tsx
│   │   ├── WhatsAppConsult.tsx
│   │   ├── Booking.tsx
│   │   ├── FAQ.tsx
│   │   ├── Contact.tsx
│   │   ├── Footer.tsx
│   │   ├── FloatingWhatsApp.tsx
│   │   ├── Chatbot.tsx          # BjayBot — site-knowledge chatbot
│   │   └── Icons.tsx            # All inline SVG icons
│   └── utils/
│       ├── contact.ts           # Centralised contact details + WhatsApp helpers
│       ├── cn.ts                # Tailwind class merger
│       ├── useReveal.ts         # Scroll-reveal IntersectionObserver hook
│       ├── knowledge.ts         # Chatbot knowledge base (site content only)
│       └── hostingGuidePdf.ts   # Branded PDF generator
├── index.html                   # HTML entry (title, meta tags, Open Graph, favicon)
├── package.json                 # Dependencies + scripts
├── tsconfig.json                # TypeScript config
├── vite.config.ts               # Vite build config (single-file output)
└── README.md                    # This file
```

---

## ✏️ Editing Common Things

### Update contact details
File: **`src/utils/contact.ts`**
```ts
export const BUSINESS = {
  name: "Bjay.Elite Business Solutions",
  tagline: "Smart Digital Solutions for Businesses.",
  whatsappRaw: "264814722735",          // Used for wa.me links (no spaces/+ sign)
  whatsappDisplay: "+264 81 472 2735",  // Shown to users
  email: "b.jayrna@gmail.com",
  location: "Namibia",
  socials: { facebook: "#", instagram: "#", tiktok: "#", linkedin: "#" },
};
```

### Update chatbot knowledge base
File: **`src/utils/knowledge.ts`** — add/edit entries in `KNOWLEDGE_BASE`.

### Change the SEO title / meta description
File: **`index.html`** — `<title>`, `<meta name="description">`, Open Graph tags.

### Add/remove portfolio items
File: **`src/components/Portfolio.tsx`** — edit the `items` array.

### Add/remove services
File: **`src/components/Services.tsx`** — edit the `services` array.

### Change colors / fonts
File: **`src/index.css`** — top of file:
```css
@theme {
  --color-ink: #0a0a0a;
  --color-gold: #d4a017;
  --color-gold-light: #f5c542;
  --font-sans: "Inter", ...;
  --font-display: "Playfair Display", ...;
}
```

---

## 🔧 Build Output

The build (`npm run build`) creates a single **`dist/index.html`** with all CSS and JavaScript inlined — **one self-contained file**, ready to drop on any host. Images remain separate in `dist/images/`.

**Total size:** ~340 KB gzipped (very fast to load globally).

---

## 📞 Support

If anything is unclear, contact **Bjay.Elite** via:
- WhatsApp: +264 81 472 2735
- Email: b.jayrna@gmail.com

---

© 2026 Bjay.Elite Business Solutions. All Rights Reserved.
